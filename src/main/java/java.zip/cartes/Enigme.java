package cartes;

import joueur.Joueur;

public class Enigme extends Carte {

	public Enigme() {
		super("L'Enigme", 0, 6, 10);
	}

	@Override
	public void effetExploit(Joueur j) {
		j.faveurMineure(4);
	}
}
