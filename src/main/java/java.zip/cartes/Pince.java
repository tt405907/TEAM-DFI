package cartes;

import joueur.Joueur;

public class Pince extends Carte {

	public Pince() {
		super("La Pince", 6, 0, 8);
	}

	public void effetExploit(Joueur j) {
		j.appliquerDe();
		j.appliquerDe();
	}
}
